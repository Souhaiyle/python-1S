# Python E1

# def main () :
# print("Hello World")
# if __name__ == '__main__':
# main()

# Python E2

# Création d'une variable 'prénom'
# username = "Souhaiyle"
# Création d'une variable 'age'
# age = 16
# Affiche le prénom et l'age
# print (username, age)
# Changer la valeur par 25
# age = 25
# Affiche la nouvelle valeur
# print (age)
# print("Salut " + username + ",vous avez " + str(age) + "ans !")

#def main () :
    # Récolter une premiere note
    #note1 = int(input("Entrer la premier note"))
    # Récolter la deuxieme note
    #note2 = int(input("Entrer la seconde note"))
    # Récolter la troisieme note
    #note3 = int(input("Entrer la derniere note"))
    # Calculer la moyenne
    #result = note1 + note2 + note3 / 3
    # Afficher le résultat
    #print ("La moyenne de l'élève est de " + str(result))



# if __name__ == '__main__':
    #main()

# Python E3